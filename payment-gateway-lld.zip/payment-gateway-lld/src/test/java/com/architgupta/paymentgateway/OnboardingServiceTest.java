package test.java.com.architgupta.paymentgateway;

import main.java.com.architgupta.paymentgateway.entity.Client;
import main.java.com.architgupta.paymentgateway.repository.ClientRepository;
import main.java.com.architgupta.paymentgateway.service.OnboardingService;
import main.java.com.architgupta.paymentgateway.service.impl.OnboardingServiceImpl;
import org.junit.Assert;
import org.junit.Test;

public class OnboardingServiceTest {

    public static final String SOME_CLIENT_NAME = "some-client-name";

    @Test
    public void testAddClient() {
        final ClientRepository clientRepository = new ClientRepository();
        final OnboardingService onboardingService = new OnboardingServiceImpl(clientRepository);

        Assert.assertFalse(onboardingService.hasClient("some-client-id"));

        final String clientId = onboardingService.addClient(SOME_CLIENT_NAME);
        final Client addedClient = onboardingService.getClient(clientId);

        Assert.assertNotNull(addedClient);
    }

    @Test
    public void testRemoveClient() {
        final ClientRepository clientRepository = new ClientRepository();
        final OnboardingService onboardingService = new OnboardingServiceImpl(clientRepository);

        final String clientId = onboardingService.addClient(SOME_CLIENT_NAME);
        Assert.assertTrue(onboardingService.hasClient(clientId));
        onboardingService.removeClient(clientId);
        Assert.assertFalse(onboardingService.hasClient(clientId));
    }
}
