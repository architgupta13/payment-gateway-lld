package main.java.com.architgupta.paymentgateway.entity;

public enum Paymode {
    NET_BANKING,
    CREDIT_CARD,
    DEBIT_CARD,
    UPI
}
