package main.java.com.architgupta.paymentgateway.model.response;

public class PaymentResponse {
}
