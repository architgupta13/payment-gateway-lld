package main.java.com.architgupta.paymentgateway.service.impl;

import main.java.com.architgupta.paymentgateway.entity.Bank;
import main.java.com.architgupta.paymentgateway.entity.Paymode;
import main.java.com.architgupta.paymentgateway.entity.Client;
import main.java.com.architgupta.paymentgateway.entity.Transaction;
import main.java.com.architgupta.paymentgateway.model.request.TransactionRequest;
import main.java.com.architgupta.paymentgateway.model.response.DistributionResponse;
import main.java.com.architgupta.paymentgateway.repository.BankRepository;
import main.java.com.architgupta.paymentgateway.repository.ClientRepository;
import main.java.com.architgupta.paymentgateway.service.PaymentService;

import java.util.Arrays;
import java.util.List;

public class PaymentServiceImpl implements PaymentService {

    private final BankRepository bankRepository;
    private final ClientRepository clientRepository;

    public PaymentServiceImpl(final BankRepository bankRepository, final ClientRepository clientRepository) {
        this.bankRepository = bankRepository;
        this.clientRepository = clientRepository;
    }

    @Override
    public List<Paymode> listSupportedPayModes() {
        return Arrays.stream(Paymode.values())
                .toList();
    }

    @Override
    public List<Paymode> listSupportedPayModes(final String clientId) {
        final Client client = this.clientRepository.getClient(clientId);
        return client.getSupportedPayModes();
    }

    @Override
    public void addSupportForPayMode(final String clientId, final Paymode newPaymode) {
        final Client client = this.clientRepository.getClient(clientId);
        client.addSupportedPaymode(newPaymode);
    }

    @Override
    public void removePayMode(final String clientId, final Paymode paymodeToDelete) {
        final Client client = this.clientRepository.getClient(clientId);
        client.removeSupportedPaymode(paymodeToDelete);
    }

    @Override
    public List<DistributionResponse> showDistribution() {
        return this.bankRepository.getAllBanks()
                .stream()
                .map(bank -> new DistributionResponse(bank.getDisplayName(), bank.getSuccessPercentage()))
                .toList();
    }

    @Override
    public boolean makePayment(final TransactionRequest transactionRequest) {
        final Client client = this.clientRepository.getClient(transactionRequest.getClientId());
        final Transaction transaction = toTransaction(transactionRequest);
        final Bank bank = client.getPaymentStrategy().getMostRelevantBank(this.bankRepository, transaction);
        return client.getPaymentStrategy().transact(bank, transaction);
    }

    private Transaction toTransaction(TransactionRequest transactionRequest) {
        return null;
    }
}
