package main.java.com.architgupta.paymentgateway.model.common;

public class GenericResponse {
    private int status;
    private Object body;
}
