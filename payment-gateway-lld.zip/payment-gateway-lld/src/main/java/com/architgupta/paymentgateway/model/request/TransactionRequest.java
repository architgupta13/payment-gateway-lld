package main.java.com.architgupta.paymentgateway.model.request;

import main.java.com.architgupta.paymentgateway.entity.Paymode;

public class TransactionRequest {
    private String clientId;
    private Double amount;
    private Paymode paymodeToUse;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Paymode getPaymodeToUse() {
        return paymodeToUse;
    }

    public void setPaymodeToUse(Paymode paymodeToUse) {
        this.paymodeToUse = paymodeToUse;
    }

    public TransactionRequest(String clientId, Double amount, Paymode paymodeToUse) {
        this.clientId = clientId;
        this.amount = amount;
        this.paymodeToUse = paymodeToUse;
    }
}
